var express = require('express');
var router = express.Router();
const Users = require("../models/users")
var id_counter = 0

function loadUsers(res){
    Users.find().then((users) => {
        res.render('admin', {users})
    })
}
router.post('/add', (req, res) => {
    const {username, password, adminStatus} = req.body
    var userModel = new Users()
    let currentTime = new Date()
    Users.find().then((users) => {
        userModel.username = username
        userModel.password = password
        userModel.userID = users.length
        userModel.creationDate = currentTime
        userModel.adminStatus = (adminStatus === "on")
        userModel.deletionDate = currentTime
        userModel.updateDate = currentTime

        userModel.save().then(() => {
            loadUsers(res)
        })
    })
})
router.post('/delete/:id', async (req, res) => {
    const userId = req.params.id;

    await Users.findByIdAndDelete(userId);
    res.redirect('/admin')

})

router.get('/', (req, res) => {
    loadUsers(res)
})
module.exports = router;
