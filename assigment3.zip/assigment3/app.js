const express = require('express')
const app = express()
const ejs = require('ejs')
const mongoose = require('mongoose')
const fs = require('fs')
const axios = require('axios')
const bodyParser = require('body-parser')
const Users = require('./models/users')
const WEATHER_API_KEY = "d83716d85906320ec9f1e42a06418b0a"
let login = fs.readFileSync('./public/loginPage.html', 'utf-8')
const PORT = 3000
var loggedIn = false
var main = fs.readFileSync('./views/mainPage.ejs', 'utf-8')
var admin = fs.readFileSync('./views/admin.ejs', 'utf-8')
const uri = 'mongodb+srv://admin:P3tH3Hfb1ngpos3D@userslog.1yvoj.mongodb.net/?retryWrites=true&w=majority&appName=UsersLog'
var isAdmin = false
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.json());
app.set('view engine', 'ejs')

const adminRouter = require('./routes/admin')
const {models} = require("mongoose");
app.use('/admin', adminRouter)

mongoose.connect(uri).then(() => console.log('Connected to MongoDB'))
    .catch(err => console.log(err))


app.get('/', (req, res) => {
    res.send(login)
})
app.get('/weather', async (req, res) => {

    const { lat = 51.15, lon = 71.42 } = req.query;

    const weatherResponse = await axios.get(
        `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&units=metric&appid=${WEATHER_API_KEY}`
    );
    const weatherData = weatherResponse.data;

    const { temp, feels_like, humidity, pressure } = weatherData.main;
    const { speed: windSpeed } = weatherData.wind;
    const { icon, description } = weatherData.weather[0];
    const { country } = weatherData.sys;
    const rain = weatherData.rain ? weatherData.rain["3h"] : "No recent rain";
    var curDate = new Date(Number(weatherData["dt"]) * 1000);
    curDate.setHours(curDate.getHours() + 5);
    var dt_txt = curDate.toISOString();
    res.render('weather', {CURRENT: dt_txt.substring(11, 19), TEMP: temp, FEEL: feels_like,
        HUM: humidity, PRESS: pressure, WIND: windSpeed, CODE:country, DESC:description, ICON:icon})
})
app.get('/mainPage', (req, res) => {
    res.render('mainPage')
})
app.post('/login', (req, res) => {
    const {username, password} = req.body
    Users.find().then((models) => {
        let findOne = false
        for(let i = 0;i < models.length;i++){
            if(models[i].username == username && models[i].password == password){
                findOne = true
                isAdmin = models[i].adminStatus
                break
            }
        }
        if(findOne){
            res.render('mainPage')
        }else{
            res.send('<h1> Incorrect password or username </h1>')
        }
    })
})
//app.get('/admin', (req, res) => {res.render('admin')})
app.listen(PORT, () =>{
    console.log(`Server is running on ${PORT}`)
})